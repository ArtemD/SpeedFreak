?package(speedfreak):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="speedfreak" command="/usr/bin/speedfreak"
