# Defaults for speedfreak initscript
# sourced by /etc/init.d/speedfreak
# installed at /etc/default/speedfreak by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
