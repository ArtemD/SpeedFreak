#
# Regular cron jobs for the speedfreak package
#
0 4	* * *	root	[ -x /usr/bin/speedfreak_maintenance ] && /usr/bin/speedfreak_maintenance
